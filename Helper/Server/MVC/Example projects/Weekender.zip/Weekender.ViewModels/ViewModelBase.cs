﻿
namespace Weekender.ViewModels
{
	#region 
	using System.Web.Mvc;
	using Weekender.Infrastructure;
	#endregion

	public abstract class ViewModelBase<TKey> : IModel<TKey>
    {
		#region IModel<TKey> Members

		/// <summary>
		/// Gets or sets unique id of View Model
		/// </summary>
		[HiddenInputAttribute]
		public TKey Id { get; set; }

		/// <summary>
		///  Compares input value and existed object id
		/// </summary>
		/// <param name="key"></param>
		/// <returns>Value indicating whether keys are equal</returns>
		public virtual bool IsKeyEqualsTo(object key)
		{
			if (!object.ReferenceEquals(Id, key) || !(Id is TKey))
			{
				return false;
			}

			return Id.Equals(key);
		}

		#endregion
	}
}
