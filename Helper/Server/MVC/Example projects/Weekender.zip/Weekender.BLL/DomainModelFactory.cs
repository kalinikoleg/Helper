﻿
namespace Weekender.BLL
{
	#region

	using System;
	using System.Collections.Generic;
	using Microsoft.Practices.ObjectBuilder2;
	using Microsoft.Practices.Unity;
	
	using Weekender.Infrastructure;
	#endregion

	/// <summary>
	/// Represents implementation of service locator
	/// </summary>
	public sealed class DomainModelFactory : IServiceProviderEx
	{
		#region Nested converter class

		public class CustomParametersResolver : ResolverOverride
		{
			private readonly Queue<InjectionParameterValue> parameterValues;

			public CustomParametersResolver(IDataRequestContext requestContext, IEnumerable<object> values)
			{
				parameterValues = new Queue<InjectionParameterValue>();

				parameterValues.Enqueue(InjectionParameterValue.ToParameter(requestContext));

				if (values != null)
				{
					foreach (var parameterValue in values)
						parameterValues.Enqueue(InjectionParameterValue.ToParameter(parameterValue));
				}
			}

			public override IDependencyResolverPolicy GetResolver(IBuilderContext context, Type dependencyType)
			{
				if (parameterValues.Count < 1)
					return null;

				var value = parameterValues.Dequeue();
				return value.GetResolverPolicy(dependencyType);
			}
		}

		#endregion

		#region Private declarations

		/// <summary>
		/// Stores an instance of data context factory
		/// </summary>
		private readonly IDataRequestContext requestContext = default(IDataRequestContext);

		/// <summary>
		/// Stores cached value of dataContext factory
		/// </summary>
		private readonly CustomParametersResolver DefaultResolver = default(CustomParametersResolver);

		/// <summary>
		/// Stores static instance of builder
		/// </summary>
		private static readonly IUnityContainer Container = new UnityContainer();

		/// <summary>
		/// Stores a cached instance type metadata
		/// </summary>
		private static readonly Type TypedTrigger = typeof(BusinessBase);

		#endregion

		#region Static constructor

		/// <summary>
		/// Initializes a new <see cref="DomainModelFactory"/> class
		/// </summary>
		static DomainModelFactory()
		{
			//ApplicationBootstrap.InitializeContainer(Container);
			//ApplicationBootstrap.InitializeMapper();
		}

		#endregion

		/// <summary>
		/// Initializes a new instance of <see cref="DomainModelFactory"/> class
		/// </summary>
		/// <param name="requestContext">Current user context</param>
		public DomainModelFactory(IDataRequestContext requestContext)
		{
			this.requestContext = requestContext;
			this.DefaultResolver = new CustomParametersResolver(requestContext, null);
		}

		#region IServiceProvider Members

		/// <summary>
		/// Gets the service object of the specified type.
		/// </summary>
		/// <param name="serviceType">An object that specifies the type of service object to get.</param>
		/// <returns> A service object of type serviceType.-or- null if there is no service object of type serviceType.</returns>
		public object GetService(Type serviceType)
		{
			if (isSelectedType(serviceType))
			{
				return Container.Resolve(serviceType, new CustomParametersResolver(this.requestContext, null));
			}

			return Container.Resolve(serviceType);
		}

		#endregion

		#region Custom IServiceProvider Members

		/// <summary>
		/// Gets the service object of the specified type.
		/// </summary>
		/// <param name="serviceType">An object that specifies the type of service object to get.</param>
		/// <returns> A service object of type serviceType.-or- null if there is no service object of type serviceType.</returns>
		public serviceType GetService<serviceType>()
		{
			return (serviceType)GetService(typeof(serviceType));
		}

		#endregion

		// Temporary solution requires meeting with Rob
		private bool isSelectedType(Type serviceType)
		{
			if (serviceType == null)
			{
				return false;
			}

			if (TypedTrigger.IsAssignableFrom(serviceType))
			{
				return true;
			}	
		
			return false;
		}
	}
}
