﻿
namespace Weekender.Data.Entity
{

	#region
	using System;
	using System.Collections.Generic;

	#endregion

}