﻿
namespace Weekender.Infrastructure
{

	#region 
	using System;
	using System.Collections.Generic;
	using System.Data.Entity;
	using System.Data.Entity.Infrastructure;
	using System.Linq;
	using System.Text;
	using System.Threading.Tasks;

	#endregion



	public class DataContextEFBase<TDbContext> : DataContextBase, IDbContextFactory<TDbContext>, IDisposable where TDbContext : DbContext
	{
		#region Fields

		private bool _disposed;
		protected String _dbConnection;
		protected TDbContext _dbContext;

		#endregion


		#region Constructors

		public DataContextEFBase(string dbConnection)
		{
			if (String.IsNullOrWhiteSpace(dbConnection)) _dbContext = Activator.CreateInstance(typeof(TDbContext)) as TDbContext;
			else
			{
				_dbConnection = dbConnection;
				_dbContext = (TDbContext)Activator.CreateInstance(typeof(TDbContext), dbConnection);
			}
		}

		public DataContextEFBase(TDbContext dbContext)
		{
			_dbContext = dbContext;
		}

		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		protected virtual void Dispose(bool disposing)
		{
			if (!_disposed && disposing && _dbContext != null) _dbContext.Dispose();
			_disposed = true;
		}

		#endregion


		#region Methods

		TDbContext IDbContextFactory<TDbContext>.Create()
		{
			return _dbContext;
		}

		#endregion


		#region IDataContext Members

		public Logging.ILogger Logger
		{
			get { throw new NotImplementedException(); }
		}

		public void TransactedFlow(Action<IDataRequestContext> action, bool forceSuppresTransaction)
		{
			throw new NotImplementedException();
		}

		#endregion

		#region IServiceProviderEx Members

		public TService GetService<TService>(params object[] constructParams)
		{
			throw new NotImplementedException();
		}

		#endregion

		#region IServiceProvider Members

		public object GetService(Type serviceType)
		{
			throw new NotImplementedException();
		}

		#endregion
	}
}
