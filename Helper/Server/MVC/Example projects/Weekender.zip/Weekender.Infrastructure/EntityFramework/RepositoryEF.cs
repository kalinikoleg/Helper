﻿
namespace Weekender.Infrastructure.EntityFramework
{
	#region 
	using System;
	using System.Collections.Generic;
	using System.Data.Entity;
	using System.Linq;
	using System.Linq.Expressions;

	#endregion

	//public class DataModel<TDataContext, TDbContext> : IDataModel<TDataContext, TDbContext>, IDataModel        
	//   where TDataContext : DataContext<TDbContext>
	//   where TDbContext : DbContext

	public class RepositoryEF<TEntity, TKey> : Repository.RepostioryBase<TEntity, TKey>
		where TEntity : class, new()
	{
		public DbSet<TEntity> Set
		{
			get
			{
				return dbContext.Set<TEntity>();
			}
		}

		#region IRepository<TEntity,TKey> Members

		public override void Delete(TKey id)
		{
			var model = this.dbContext.Set<TEntity>().Find(id);
			if (model is TEntity)
			{
				this.Set.Remove(model);
			}
		}

		public override TEntity Get(TKey id)
		{
			return this.Set.Find(id);
		}

		public override void Post(TEntity entity)
		{
			this.Set.Add(entity);
		}

		public override void Put(TEntity entity)
		{
			var entry = this.dbContext.Entry<TEntity>(entity);
			if (entry != null)
			{
				if (entry.State == EntityState.Detached)
				{
					var attachedEntity = this.Set.Attach(entity);
					entry = this.dbContext.Entry<TEntity>(attachedEntity);
				}
				entry.State = EntityState.Modified;
			}
			else
			{
				this.Post(entity);
			}
		}

		public override IEnumerable<TEntity> SqlQuery(string sql, object[] parameters)
		{
			return dbContext.Database.SqlQuery<TEntity>(sql, parameters);
		}

		public override IQueryable<TEntity> Query(
			Expression<Func<TEntity, bool>> predicate,
			Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
			int? pageNumber = null,
			int? pageSize = null)
		{
			IQueryable<TEntity> query = dbContext.Set<TEntity>();

			if (orderBy != null)
				query = orderBy(query);

			if (predicate != null)
				query = query.Where(predicate);

			if (pageNumber != null && pageSize != null)
				query = query.Skip((pageNumber.Value - 1) * pageSize.Value).Take(pageSize.Value);

			return query;
		}

		#endregion

		public void Commit()
		{
			base.CurrentContext.TransactedFlow((item, dsd) => { this.dbContext.SaveChanges(); }, false);
		}

		private DbContext dbContext;
	}
}