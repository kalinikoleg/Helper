﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Weekender.Infrastructure.EntityFramework
{
	public abstract class DataContextFactory<TDataContext, TDbContext> : IDataContextFactory<TDataContext, TDbContext>
		where TDataContext : DataContext<TDbContext>
		where TDbContext : System.Data.Entity.DbContext
	{

		#region Constructors

		public DataContextFactory()
		{
		}

		public DataContextFactory(string dbConnection)
		{
			this.dataContextFunc = new Func<DataContext<TDbContext>>(() => (TDataContext)Activator.CreateInstance(typeof(TDataContext), dbConnection));
		}

		public DataContextFactory(TDbContext dbContext)
		{
			this.dataContextFunc = new Func<DataContext<TDbContext>>(() => (TDataContext)Activator.CreateInstance(typeof(TDataContext), dbContext));
		}

		#endregion


		#region Methods

		public virtual DataContext<TDbContext> Create()
		{
			if (dataContext == null)
			{
				dataContext = dataContextFunc();
			}
			return dataContext;
		}

		#endregion

		#region Members

		DataContext<TDbContext> dataContext;
		protected Func<DataContext<TDbContext>> dataContextFunc;

		#endregion
	}
}