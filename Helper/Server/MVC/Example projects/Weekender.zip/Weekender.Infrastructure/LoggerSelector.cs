﻿
namespace Weekender.Infrastructure.Logging
{
	#region

	using System;

	#endregion

	/// <summary>
	/// Represents instance that manages of loggers
	/// </summary>
	public sealed class LoggerSelector : ILogger, ICloneable
	{
		#region Nested members

		/// <summary>
		/// Represents stub-object of <see cref="ILogger"/> interface
		/// </summary>
		private class EmptyLogger : ILogger
		{
			#region ILogger Members

			/// <summary>
			/// Writes simple message with level
			/// </summary>
			/// <param name="message">Message to write</param>
			/// <param name="msgLevel">Message level</param>
			/// <exception cref="InvalidOperationException">When write transaction failed</exception>
			public void WriteMessage(string message, MessageLevel msgLevel)
			{
			}

			/// <summary>
			/// Writes formatted message with level
			/// </summary>
			/// <param name="msgLevel">Message level</param>
			/// <param name="msgTemplateId">Message template to write</param>
			/// <param name="values">List of values to format them by template</param>
			/// <exception cref="InvalidOperationException">When write transaction failed</exception>
			/// <exception cref="ArgumentException">When values quantity does not match template input</exception>
			public void WriteMessageByTemplate(MessageLevel msgLevel, string msgTemplateId, params object[] values)
			{
			}

			#endregion
		}
		#endregion

		/// <summary>
		/// Setups a new instance of <see cref="ILogger"/> object to manager
		/// </summary>
		/// <param name="loggerInstance">Instance of logger object</param>
		/// <exception cref="StackOverflowException">When loggerInstance is the instance of LoggerSelector</exception>
		public void Initialize(ILogger loggerInstance)
		{
			lock (this.mutex2)
			{
				if (loggerInstance == null)
				{
					loggerInstance = new EmptyLogger();
				}

				if (loggerInstance.GetType().IsAssignableFrom(typeof(LoggerSelector)))
				{
					throw new StackOverflowException("Recursive references is not allowed");
				}

				this.logger = loggerInstance;
			}
		}

		#region ILogger Members

		/// <summary>
		/// Writes simple message with level
		/// </summary>
		/// <param name="message">Message to write</param>
		/// <param name="msgLevel">Message level</param>
		/// <exception cref="InvalidOperationException">When write transaction failed</exception>
		public void WriteMessage(string message, MessageLevel msgLevel)
		{
			this.logger.WriteMessage(message, msgLevel);
		}

		/// <summary>
		/// Writes formatted message with level
		/// </summary>
		/// <param name="msgLevel">Message level</param>
		/// <param name="msgTemplateId">Message template to write</param>
		/// <param name="values">List of values to format them by template</param>
		/// <exception cref="InvalidOperationException">When write transaction failed</exception>
		/// <exception cref="ArgumentException">When values quantity does not match template input</exception>
		public void WriteMessageByTemplate(MessageLevel msgLevel, string msgTemplateId, params object[] values)
		{
			this.logger.WriteMessageByTemplate(msgLevel, msgTemplateId, values);
		}

		#endregion

		#region ICloneable Members

		/// <summary>
		/// Creates a new copy of current instance of LogManager
		/// </summary>
		/// <returns>Instance of cloned object</returns>
		public object Clone()
		{
			var manager = new LoggerSelector()
			{
				logger = this.logger
			};

			return manager;
		}

		#endregion

		#region Static members

		/// <summary>
		/// Gets instance of LogManager <see cref="LoggerSelector"/> class
		/// </summary>
		public static LoggerSelector Instance
		{
			get
			{
				lock (Mutex)
				{
					if (logManager == null)
					{
						logManager = new LoggerSelector();
						logManager.Initialize(null);
					}
				}

				return logManager;
			}
		}

		/// <summary>
		/// Stores a sync object for static logic
		/// </summary>
		private static readonly object Mutex = new object();

		/// <summary>
		/// Stores a persistent entity of <see cref="LoggerSelector"/> object
		/// </summary>
		private static LoggerSelector logManager = default(LoggerSelector);
		#endregion

		/// <summary>
		/// Stores a sync object for class logic
		/// </summary>
		private readonly object mutex2 = new object();

		/// <summary>
		/// Stores an instance of current logger
		/// </summary>
		private ILogger logger = null;
	}
}
