﻿
namespace Weekender.Infrastructure
{
	#region

	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using System.Threading.Tasks;
	using Weekender.Infrastructure;
	using Weekender.Infrastructure.EntityFramework;

	#endregion

	/// <summary>
	/// Represents a bridge base class of all domain models of retailer context
	/// </summary>
	public abstract class BusinessBase : BusinessModel<DataModel<DataContext<RetailerDbContext>, RetailerDbContext>, DataContext<RetailerDbContext>, RetailerDbContext>
	{
		/// <summary>
		/// Initializes a new instance of <see cref="BusinessBase"/> class from existed request data context
		/// </summary>
		/// <param name="requestContext"></param>
		public BusinessBase(IDataRequestContext requestContext)
			: base(new DataContextFactory(requestContext))
		{
			this.RequestContext = requestContext;
		}

		/// <summary>
		/// Gets an instance of current request context
		/// </summary>
		public IDataRequestContext RequestContext { get; private set; }

		/// <summary>
		/// Resets cache of related dictionaries
		/// </summary>
		public void ResetCache()
		{
			// TODO: Implement reset the cache bind logic here
		}
	}
}
