﻿
namespace Weekender.Infrastructure
{
	#region 
	using System;
	using System.Collections.Generic;

	#endregion

	/// <summary>
	/// 
	/// </summary>
	public interface IServiceProviderEx: IServiceProvider
	{
		/// <summary>
		/// Gets the service object of the specified type.
		/// </summary>
		/// <typeparam name="TService"><An object that specifies the type of service object to get/typeparam>
		/// <param name="constructParams">LIst of construction arguments</param>
		/// <returns>A service object of type serviceType.-or- null if there is no service object	of type serviceType.</returns>
		TService GetService<TService>(params object[] constructParams);
	}
}
