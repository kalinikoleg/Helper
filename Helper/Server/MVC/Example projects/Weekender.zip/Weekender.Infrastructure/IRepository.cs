﻿
namespace Weekender.Infrastructure
{
	#region 
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Linq.Expressions;
	using Weekender.Infrastructure.DataContext;

	#endregion

	public interface IRepository<TEntity, Key> where TEntity : IModel<Key>
	{
		IDataContext CurrentContext { get; }

		void Delete(Key id);

		TEntity Get(Key id);

		TEntity Post(TEntity entity);

		TEntity Put(TEntity entity);

		IEnumerable<TEntity> SqlQuery(string sql, object[] parameters);

		IQueryable<TEntity> Query(
			Expression<Func<TEntity, bool>> predicate,
			Func<IQueryable<TEntity>,
			IOrderedQueryable<TEntity>> orderBy = null,
			int? pageNumber = null,
			int? pageSize = null);

		

		//Int32 SqlCommand(String query, Object[] parameters = null);
		//System.Data.Entity.Database
		//DbSqlQuery<TEntity> SqlQuery<TEntity>(String sql, Object[] parameters);        
	}
}
