﻿
namespace Weekender.Infrastructure.Repository
{
	#region 
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Linq.Expressions;

	#endregion

	public abstract class RepostioryBase<TEntity, TKey> : IRepository<TEntity, TKey>
		where TEntity : class
	{
		public RepostioryBase(IDataContext context)
		{
			this.CurrentContext = context;
		}

		#region IRepository<TEntity,TKey> Members

		public IDataContext CurrentContext
		{
			get;
			private set;
		}

		public abstract void Delete(TKey id);

		public abstract TEntity Get(TKey id);

		public abstract void Post(TEntity entity);

		public abstract void Put(TEntity entity);

		public abstract IEnumerable<TEntity> SqlQuery(string sql, object[] parameters);

		public abstract IQueryable<TEntity> Query(
			Expression<Func<TEntity, bool>> predicate,
			Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
			int? pageNumber = null,
			int? pageSize = null);

		#endregion
	}
}
