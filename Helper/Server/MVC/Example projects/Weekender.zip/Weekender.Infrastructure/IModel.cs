﻿
namespace Weekender.Infrastructure
{
	#region

	using System;
	using System.Collections.Generic;	
	#endregion

	/// <summary>
	/// Represents base abstraction of 	model
	/// </summary>
	/// <typeparam name="TKey"></typeparam>
	public interface IModel<TKey>
	{
		/// <summary>
		/// Gets or sets value indicating unique identifier of View Model
		/// </summary>
		TKey Id { get; set; }

		/// <summary>
		///  Compares input value and existed object id
		/// </summary>
		/// <param name="key"></param>
		/// <returns>Value indicating whether keys are equal</returns>
		bool IsKeyEqualsTo(object key);
	}
}
