﻿
namespace Weekender.Infrastructure.Logging
{
	#region

	using System;
	using System.IO;

	#endregion

	/// <summary>
	/// Represents interface of Logger
	/// </summary>
	public interface ILogger
	{
		/// <summary>
		/// Writes simple message with level
		/// </summary>
		/// <param name="message">Message to write</param>
		/// <param name="msgLevel">Message level</param>
		/// <exception cref="InvalidOperationException">When write transaction failed</exception>
		void WriteMessage(string message, MessageLevel msgLevel);

		/// <summary>
		/// Writes formatted message with level
		/// </summary>
		/// <param name="msgLevel">Message level</param>
		/// <param name="msgTemplateId">Message template to write</param>
		/// <param name="values">List of values to format them by template</param>
		/// <exception cref="InvalidOperationException">When write transaction failed</exception>
		/// <exception cref="ArgumentException">When values quantity does not match template input</exception>
		void WriteMessageByTemplate(MessageLevel msgLevel, string msgTemplateId, params object[] values);
	}
}
