﻿
namespace Weekender.Infrastructure
{
	#region

	using System;
	using System.Transactions;
	using Weekender.Infrastructure.Logging;
	#endregion

	public abstract class DataContextBase<TContextType> : IDataContext
	{
		public DataContextBase(string conString, bool escalateException)
		{
			this.escalateException = escalateException;

			if (escalateException)
			{
				this.escalationLevel = MessageLevel.Warning;
			}
			
			InitializeContext(conString, out internalContext);
		}

		protected abstract void InitializeContext(string conString, out TContextType internalContext);

		#region IDataContext Members

		/// <summary>
		/// Gets instance of Logger
		/// </summary>
		public Logging.ILogger Logger { get { return this.loggerSelector; } }

		/// <summary>
		///  Provides UoW mechanism
		/// </summary>
		/// <forceSuppresTransaction></forceSuppresTransaction>
		/// <param name="action">Handler that should be routed by transaction</param>
		/// <returns></returns>
		public virtual void TransactedFlow(Action<IDataRequestContext> action, IDataRequestContext context, bool forceSuppresTransaction)
		{
			try
			{
				var scopeOption = forceSuppresTransaction ? TransactionScopeOption.Suppress : TransactionScopeOption.Required;
				using (var tran = new TransactionScope(scopeOption))
				{
					action(context);
					tran.Complete();
				}
			}
			catch (Exception err)
			{
				this.loggerSelector.WriteMessage(err.Message, escalationLevel);
				if (escalateException)
				{
					throw;
				}
			}
		}

		#endregion

		#region IDisposable Members

		public abstract void Dispose();

		#endregion

		private readonly bool escalateException = false;
		private readonly MessageLevel escalationLevel = MessageLevel.Error;
		private readonly LoggerSelector loggerSelector = LoggerSelector.Instance;
		private readonly TContextType internalContext = default(TContextType);
	}
}
