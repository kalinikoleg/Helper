﻿
namespace Weekender.Infrastructure
{
	#region 
	using System;
	using System.Collections.Generic;
	using System.Transactions;
	using Weekender.Infrastructure.Logging;

	#endregion

	public interface IDataContext : IDisposable
	{
		/// <summary>
		/// Gets an instance of current logger
		/// </summary>
		ILogger Logger { get; }

		IDataRequestContext CreateRequestContext();

		/// <summary>
		/// Gets or sets repository instance of container
		/// </summary>
		IServiceProviderEx RepositoryContainer { get; set; }

		/// <summary>
		///  Provides UoW mechanism
		/// </summary>
		/// <forceSuppresTransaction></forceSuppresTransaction>
		/// <param name="action">Handler that should be routed by transaction</param>
		void TransactedFlow(Action<IDataRequestContext> action, IDataRequestContext context, bool forceSuppresTransaction);	
	}
}
