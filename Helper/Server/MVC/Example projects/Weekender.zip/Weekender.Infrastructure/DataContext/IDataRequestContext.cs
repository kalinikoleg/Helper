﻿
namespace Weekender.Infrastructure
{
	#region 
	using System;
	using System.Collections.Generic;

	#endregion
	
	/// <summary>
	/// Represents object provides access to current operation context
	/// </summary>
	public interface IDataRequestContext
	{
		/// <summary>
		/// Gets a database connection string
		/// </summary>
		string DbConnection { get; }

		/// <summary>
		/// Gets instance of ORM entity
		/// </summary>
		IDataContext DataContext { get; }	

		/// <summary>
		/// Gets instance of cached values
		/// </summary>
		IRequestState RequestState { get; }
	}
}
