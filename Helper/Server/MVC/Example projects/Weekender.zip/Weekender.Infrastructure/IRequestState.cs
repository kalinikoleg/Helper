﻿
namespace Weekender.Infrastructure
{
	#region 
	using System;
	using System.Collections.Generic;
	using System.Linq;
	using System.Text;
	using System.Threading.Tasks;

	#endregion
	
	public interface IRequestState
	{
		void AddToCache(string key, object value);
		
		bool Exists(string key);

		TValue GetValue<TValue>(string key, TValue defaultValue);
	}
}
